Here you will find a packaged solution using pipelines: https://github.com/keurcien/car-accidents
